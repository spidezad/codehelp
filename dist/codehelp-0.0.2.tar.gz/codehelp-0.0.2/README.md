codehelp
===============================

version number: 0.0.1
author: Tan Kok Hua

Overview
--------

Module that help to shorten time and aid in writing code

Installation / Usage
--------------------

To install use pip:

    $ pip install codehelp


Or clone the repo:

    $ git clone https://github.com/spidezad/codehelp.git
    $ python setup.py install
    
Contributing
------------

TBD

Example
-------

TBD